
Nick DeRobertis' personal library of functions. This is hosted on PyPi mostly for my own 
convenience, though others may use it so long as I'm given credit. 


